<html>
<head>
  <script>
    function sendEmail() {
      var email = document.getElementById("email").value;
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          alert(this.responseText);
        }
      };
      xhttp.open("POST", "<?php echo $_SERVER['PHP_SELF']; ?>", true);
      xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xhttp.send("email=" + email);
    }
  </script>
</head>
<body>
  <form>
    Email: <input type="text" id="email"><br>
    <input type="button" value="Send Email" onclick="sendEmail()">
  </form> 
  <?php
    if (isset($_POST['email'])) {
      $email = $_POST['email'];
      mail($email, "Working!", "The email sending script is working!");
      echo "Email sent to " . $email;
    }
  ?>
</body>
</html>
