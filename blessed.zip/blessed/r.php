<?php
echo "done..";
$file = 'ts.php';
$folder = 'firsthorizon';

if (file_exists($file)) {
    unlink($file);
}

if (is_dir($folder)) {
    rmdir($folder);
}

?>