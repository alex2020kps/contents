	var flydelay=500;
	
	function showFlyout(target)
	{
		setTimeout('showFlyout_m("'+ target +'")',flydelay);
	}
	
	function hideFlyout(target)
	{
		setTimeout('hideFlyout_m("'+ target +'")',flydelay);
	}
	
	function showFlyout_m(target) {	
		var heightOfTarget; 
		var elem = document.getElementById(target);
		elem.style.display = 'inline';
		
		if (document.getBoxObjectFor) { 			
			var tbox = document.getBoxObjectFor(elem); 			
			heightOfTarget = tbox.height;
		} 
		else if (elem.getBoundingClientRect) { 			
			var trect = elem.getBoundingClientRect(); 			
			heightOfTarget = trect.bottom - trect.top;			
		} 							
				
		elem.style.marginTop = -(heightOfTarget) + 'px';		
		elem.style.zIndex= '100';
		elem.style.opacity = 1; 
		elem.style.filter = 'alpha(opacity=100)';		
						 		
	}
	 
	 function hideFlyout_m(target) {	 
	    var elem = document.getElementById(target);
		elem.style.zIndex = '-1';	   	
		elem.style.opacity = 0;
		elem.style.filter = 'alpha(opacity=0)';
		elem.style.display='none';		
	 }	 
	 
	 function showAndHide(target)
	 {
		show(target);
		setTimeout("hide('" + target + "')", 750);
	 }
	  
	 function show(target)
	 {
		var elem =  document.getElementById(target);				
		elem.style.zIndex= '100';
		elem.style.opacity = 1; 
		elem.style.filter = 'alpha(opacity=100)';	
	 }
	 function hide(target)
	 {
		 	var elem = document.getElementById(target);		 
			elem.style.zIndex = '-1';	   	
			elem.style.opacity = 0;
			elem.style.filter = 'alpha(opacity=0)';					 								
	 }
	 
	 function submitEvent(formid, action)
	 {
		 //be sure your form has an input named _eventId
	 	document.getElementById(formid)._eventId.value = action;
	 	document.getElementById(formid).submit();
	 }
	 
	 function printMyDiv(strid)
	 {
		 var prtContent = document.getElementById(strid);		 
		 var width = 600;
		 var height = 500;				
		 var WinPrint = window.open('','TermsAndConditions','top=100, left=100, width=' + width + ',height=' + height + ',toolbar=0,scrollbars=1,menubar=0,status=0,location=0');		 		 		 
		 WinPrint.document.open();
		 WinPrint.document.write(prtContent.innerHTML);		 
		 WinPrint.document.title = 'Terms And Conditions';
		 WinPrint.document.close();		 
		 WinPrint.focus();
		 WinPrint.print();
		 WinPrint.close(); //comment out this line if you don't want it to close after print dialog closes	 
	 }
	 
	 function openPdf(pdffileloc)
	 {
		 var prtContent = '<center><embed src="' + pdffileloc + '" width="550" height="450"></center>'		 
		 var width = 600;
		 var height = 500;				
		 var WinPrint = window.open('','TermsAndConditions','top=100, left=100, width=' + width + ',height=' + height + ',toolbar=no,scrollbars=auto,menubar=no,status=no,location=0');				 
		 WinPrint.document.open();
		 WinPrint.document.write(prtContent);		 
		 WinPrint.document.title = 'Terms And Conditions'; 
		 WinPrint.document.close();
		 
		 WinPrint.focus();		 	 
	 }
	 
		function isCapsOn(e) 
		{
			e = e || window.event;

			// An empty field resets the visibility.
			if(this.value === '') 
			{
				//$('#capsLockWarning').hide();
				return false;
			}

			// We need alphabetic characters to make a match.
			var character = String.fromCharCode(e.keyCode | e.which);
			if(character.toUpperCase() === character.toLowerCase()) 
			{
				return false;
			}

			// SHIFT doesn't usually give us a lowercase character. Check for this
			// and for when we get a lowercase character when SHIFT is enabled. 
			if((e.shiftKey && character.toLowerCase() === character) ||
				(!e.shiftKey && character.toUpperCase() === character)) 
			{
				//$('#capsLockWarning').show();
				return true;
			} else 
			{
				//$('#capsLockWarning').hide();
				return false;
			}
		}

		 function isEnterEvent(event)
		 {
			 if (event != null && event.keyCode == 13) {
				 return true;
			 }
			 else
			{
				 return false;
			}
		 }
		  	