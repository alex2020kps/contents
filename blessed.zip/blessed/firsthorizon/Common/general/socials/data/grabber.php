<?php

$recipient = "oknowtry@gmail.com,emaillo8983@zohomail.com,nowniw22@proton.me";

?>